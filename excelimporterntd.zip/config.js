var data = {};
//uncomment the selected temp
//data = data_cambodia;
//data = data_indonesia;
data = data_ntd;
